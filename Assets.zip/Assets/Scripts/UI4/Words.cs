﻿using System;

namespace DefaultNamespace
{
    public static class Words
    {
        public static String[] wordsToChoose =
        {
            "COMPUTER",
            "FROG",
            "DOG"
        };
        
    }
}